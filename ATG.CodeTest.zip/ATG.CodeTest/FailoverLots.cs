﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATG.CodeTest
{
    public class FailoverLots
    {
        public DateTime DateTime { get; set; }
    }
}
