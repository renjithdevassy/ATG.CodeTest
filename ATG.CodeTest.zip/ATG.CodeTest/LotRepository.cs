﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATG.CodeTest
{
   public class LotRepository
    {
        public Lot LoadCustomer()
        {
            return new Lot();
        }
    }
}
